function printError(Id, Msg) {
    document.getElementById(Id).innerHTML = Msg;
}

function validateForm() {

    var name = document.Form.name.value;
    var email = document.Form.email.value;
    var mobile = document.Form.mobile.value;
    var tech = document.Form.tech.value;
    var con = document.Form.con.value;


    var nameErr = emailErr = mobileErr = techErr = conErr = true;


    if (name == "") {
        printError("nameErr", "Please enter your name");
        var elem = document.getElementById("name");
        elem.classList.add("input-2");
        elem.classList.remove("input-1");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(name) === false) {
            printError("nameErr", "Please enter a valid name");
            var elem = document.getElementById("name");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("nameErr", "");
            nameErr = false;
            var elem = document.getElementById("name");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");


        }
    }


    if (email == "") {
        printError("emailErr", "Please enter your email address");
        var elem = document.getElementById("email");
        elem.classList.add("input-2");
        elem.classList.remove("input-1");
    } else {

        var regex = /^\S+@\S+\.\S+$/;
        if (regex.test(email) === false) {
            printError("emailErr", "Please enter a valid email address");
            var elem = document.getElementById("email");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("emailErr", "");
            emailErr = false;
            var elem = document.getElementById("email");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");

        }
    }


    if (mobile == "") {
        printError("mobileErr", "Please enter your mobile number");
        var elem = document.getElementById("mobile");
        elem.classList.add("input-2");
        elem.classList.remove("input-1");
    } else {
        var regex = /^[1-9]\d{9}$/;
        if (regex.test(mobile) === false) {
            printError("mobileErr", "Please enter a valid 10 digit mobile number");
            var elem = document.getElementById("mobile");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("mobileErr", "");
            mobileErr = false;
            var elem = document.getElementById("mobile");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");
        }
    }
    if (con == "") {
        printError("conErr", "Please enter valid query");
        var elem = document.getElementById("con");
        elem.classList.add("input-2");
        elem.classList.remove("input-1");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(con) === false) {
            printError("conErr", "Please enter a valid query");
            var elem = document.getElementById("con");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("conErr", "");
            conErr = false;
            var elem = document.getElementById("con");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");


        }
    }
    if (tech == "") {
        printError("techErr", "Please enter valid query");
        var elem = document.getElementById("tech");
        elem.classList.add("input-2");
        elem.classList.remove("input-1");
    } else {
        var regex = /^[a-zA-Z\s]+$/;
        if (regex.test(tech) === false) {
            printError("techErr", "Please enter a valid query");
            var elem = document.getElementById("tech");
            elem.classList.add("input-2");
            elem.classList.remove("input-1");
        } else {
            printError("techErr", "");
            techErr = false;
            var elem = document.getElementById("tech");
            elem.classList.add("input-1");
            elem.classList.remove("input-2");


        }
    }

    if ((nameErr || emailErr || mobileErr || techErr || conErr) == true) {
        return false;
    }
};